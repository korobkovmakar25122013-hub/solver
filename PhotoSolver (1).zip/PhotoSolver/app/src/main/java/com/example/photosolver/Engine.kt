package com.example.photosolver

object Engine {
    /** Решает всё, что нашёл в тексте: примеры построчно и текстовую задачу целиком. */
    fun solveText(text: String): String {
        val lines = text.lines().map { it.trim() }.filter { it.isNotEmpty() }
        val sb = StringBuilder()

        for (line in lines) {
            if (Solver.isWordProblem(line)) continue
            val s = Solver.solve(line) ?: continue
            sb.append(s.task).append("\n→ ").append(s.answer).append("\n\n")
        }

        if (Solver.isWordProblem(text)) {
            val w = WordSolver.solve(text)
            if (w != null) {
                sb.append("Решение задачи:\n").append(w).append("\n\n")
            } else {
                sb.append(
                    "Не смог разобрать задачу. Офлайн-режим решает типовые задачи: " +
                        "сумма и разность, «на N больше/меньше», «в N раз», «по N», движение " +
                        "(скорость, время, путь), проценты, среднее, периметр и площадь. " +
                        "Попробуйте записать условие короче.\n\n"
                )
            }
        }

        return if (sb.isEmpty()) {
            "Не нашёл пример или задачу. Проверьте текст."
        } else {
            sb.toString().trim()
        }
    }
}
