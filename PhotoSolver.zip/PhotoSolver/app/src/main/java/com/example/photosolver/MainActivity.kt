package com.example.photosolver

import android.content.ContentValues
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

class MainActivity : AppCompatActivity() {

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private lateinit var image: ImageView
    private lateinit var output: TextView
    private lateinit var input: EditText
    private lateinit var photoPanel: View
    private lateinit var textPanel: View
    private var photoUri: Uri? = null

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val uri = photoUri
        if (ok && uri != null) process(uri)
    }

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) process(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        image = findViewById(R.id.image)
        output = findViewById(R.id.output)
        input = findViewById(R.id.input)
        photoPanel = findViewById(R.id.photoPanel)
        textPanel = findViewById(R.id.textPanel)

        findViewById<Button>(R.id.tabPhoto).setOnClickListener {
            photoPanel.visibility = View.VISIBLE
            textPanel.visibility = View.GONE
        }
        findViewById<Button>(R.id.tabText).setOnClickListener {
            photoPanel.visibility = View.GONE
            textPanel.visibility = View.VISIBLE
        }

        findViewById<Button>(R.id.btnSolve).setOnClickListener {
            output.text = Engine.solveText(input.text.toString())
        }

        findViewById<Button>(R.id.btnCamera).setOnClickListener {
            val values = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "task_${System.currentTimeMillis()}.jpg")
                put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
            photoUri = uri
            if (uri != null) takePhoto.launch(uri)
        }

        findViewById<Button>(R.id.btnGallery).setOnClickListener {
            pickPhoto.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
        }
    }

    private fun process(uri: Uri) {
        try {
            val bitmap = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { decoder, info, _ ->
                decoder.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val side = maxOf(info.size.width, info.size.height)
                if (side > 2000) decoder.setTargetSampleSize(side / 2000 + 1)
            }
            image.setImageBitmap(bitmap)
            output.text = "Распознаю…"
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { text ->
                    val mlText = text.textBlocks.flatMap { it.lines }.joinToString("\n") { it.text }
                    if (tessAvailable()) {
                        Thread {
                            val tess = runTesseract(bitmap)
                            runOnUiThread { finishPhoto(mlText, tess) }
                        }.start()
                    } else {
                        finishPhoto(mlText, null)
                    }
                }
                .addOnFailureListener { output.text = "Не удалось распознать: ${it.message}" }
        } catch (e: Exception) {
            output.text = "Не удалось открыть фото: ${e.message}"
        }
    }

    private fun finishPhoto(mlText: String, tessText: String?) {
        // Если на фото задача словами, берём русский распознаватель, иначе ML Kit (лучше читает цифры)
        val source = if (tessText != null && Solver.isWordProblem(tessText)) tessText else mlText
        val result = Engine.solveText(source)
        val sb = StringBuilder("Распознано:\n").append(source.trim()).append("\n\n").append(result)
        if (!tessAvailable() && Solver.isWordProblem(mlText).not() && result.startsWith("Не нашёл")) {
            sb.append("\n\nЕсли на фото задача словами, добавьте русский словарь rus.traineddata (см. README).")
        }
        output.text = sb.toString()
    }

    private fun tessAvailable(): Boolean =
        (assets.list("tessdata") ?: emptyArray()).contains("rus.traineddata")

    private fun runTesseract(bitmap: Bitmap): String? {
        return try {
            val dir = File(filesDir, "tessdata").apply { mkdirs() }
            val data = File(dir, "rus.traineddata")
            if (!data.exists()) {
                assets.open("tessdata/rus.traineddata").use { i ->
                    data.outputStream().use { o -> i.copyTo(o) }
                }
            }
            val api = TessBaseAPI()
            if (!api.init(filesDir.absolutePath, "rus")) {
                api.recycle()
                return null
            }
            api.setImage(bitmap)
            val text = api.getUTF8Text()
            api.recycle()
            text
        } catch (e: Exception) {
            null
        }
    }
}
