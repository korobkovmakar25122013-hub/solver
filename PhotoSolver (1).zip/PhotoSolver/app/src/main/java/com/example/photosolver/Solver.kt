package com.example.photosolver

import kotlin.math.abs
import kotlin.math.pow
import kotlin.math.sqrt

data class Solution(val task: String, val answer: String)

/** Разбор выражений: + - * / ^ скобки, %, неявное умножение (2x, 3(4+1)), переменная x. */
private class Parser(private val s: String, private val x: Double) {
    private var i = 0

    fun parse(): Double {
        val v = expr()
        if (i != s.length) throw IllegalArgumentException("Лишние символы")
        return v
    }

    private fun peek(): Char = if (i < s.length) s[i] else '\u0000'

    private fun expr(): Double {
        var v = term()
        while (true) {
            when (peek()) {
                '+' -> { i++; v += term() }
                '-' -> { i++; v -= term() }
                else -> return v
            }
        }
    }

    private fun term(): Double {
        var v = unary()
        while (true) {
            val c = peek()
            when {
                c == '*' -> { i++; v *= unary() }
                c == '/' -> {
                    i++
                    val d = unary()
                    if (d == 0.0) throw IllegalArgumentException("Деление на ноль")
                    v /= d
                }
                c == 'x' || c == '(' -> v *= unary()
                else -> return v
            }
        }
    }

    private fun unary(): Double = when (peek()) {
        '-' -> { i++; -unary() }
        '+' -> { i++; unary() }
        else -> power()
    }

    private fun power(): Double {
        val base = atom()
        return if (peek() == '^') { i++; base.pow(unary()) } else base
    }

    private fun atom(): Double {
        val c = peek()
        var v: Double
        when {
            c == '(' -> {
                i++
                v = expr()
                if (peek() != ')') throw IllegalArgumentException("Нет закрывающей скобки")
                i++
            }
            c == 'x' -> { i++; v = x }
            c.isDigit() || c == '.' -> {
                val start = i
                while (peek().isDigit() || peek() == '.') i++
                v = s.substring(start, i).toDouble()
            }
            else -> throw IllegalArgumentException("Не удалось прочитать выражение")
        }
        while (peek() == '%') { i++; v /= 100 }
        return v
    }
}

object Solver {
    private val percentOf =
        Regex("""(\d+(?:[.,]\d+)?)\s*%\s*(?:от|of)\s*(\d+(?:[.,]\d+)?)""", RegexOption.IGNORE_CASE)
    private val notAllowed = Regex("[^0-9x+\\-*/^().%=?]")

    private val words = Regex("[A-Za-zА-Яа-яЁё]{2,}")

    /** Приводит текст после распознавания к виду, который понимает парсер. */
    fun normalize(raw: String): String {
        var s = raw.lowercase().replace(percentOf, "\$1%*\$2")
        val hadWords = words.containsMatchIn(s)
        s = words.replace(s, " ") // слова вроде «Реши:» отбрасываем
        s = s.replace('×', '*').replace('·', '*').replace('÷', '/')
            .replace(':', if (hadWords) ' ' else '/')
            .replace('−', '-').replace('–', '-').replace('—', '-')
            .replace(',', '.')
            .replace('х', 'x') // русская «х»
        return s.replace(notAllowed, "")
    }

    /** Похоже на текстовую задачу (много слов): такие решает WordSolver. */
    fun isWordProblem(raw: String): Boolean =
        Regex("[A-Za-zА-Яа-яЁё]{3,}").findAll(raw).count() >= 4

    fun solve(raw: String): Solution? {
        val t = normalize(raw)
        if (t.length < 3 || t.none { it.isDigit() } || t.none { it in "+-*/^%=" }) return null
        return try {
            if (t.contains('=')) {
                val parts = t.split('=')
                if (parts.size != 2) return null
                val left = parts[0]
                val right = parts[1]
                if (right.isEmpty() || right == "?") {
                    Solution("$left =", fmt(Parser(left.replace('x', '*'), 0.0).parse()))
                } else {
                    solveEquation(left, right)
                }
            } else {
                Solution(t, fmt(Parser(t.replace('x', '*'), 0.0).parse()))
            }
        } catch (e: Exception) {
            null
        }
    }

    private fun solveEquation(l: String, r: String): Solution {
        val task = "$l = $r"
        if (!l.contains('x') && !r.contains('x')) {
            val a = Parser(l, 0.0).parse()
            val b = Parser(r, 0.0).parse()
            val ans = if (abs(a - b) < 1e-9) "верно" else "неверно (${fmt(a)} ≠ ${fmt(b)})"
            return Solution(task, ans)
        }
        // f(x) = левая часть − правая; восстанавливаем a, b, c из f(0), f(1), f(-1)
        val f = { x: Double -> Parser(l, x).parse() - Parser(r, x).parse() }
        val c = f(0.0)
        val p = f(1.0)
        val m = f(-1.0)
        val a = (p + m) / 2 - c
        val b = (p - m) / 2
        val expected = 4 * a + 2 * b + c
        if (abs(f(2.0) - expected) > 1e-6 * (1 + abs(expected))) {
            return Solution(task, "поддерживаются уравнения не выше 2-й степени")
        }
        val eps = 1e-9
        val ans = when {
            abs(a) < eps && abs(b) < eps ->
                if (abs(c) < eps) "x — любое число" else "решений нет"
            abs(a) < eps -> "x = ${fmt(-c / b)}"
            else -> {
                val d = b * b - 4 * a * c
                when {
                    d < -eps -> "корней нет (D = ${fmt(d)})"
                    abs(d) <= eps -> "x = ${fmt(-b / (2 * a))} (D = 0)"
                    else -> {
                        val sq = sqrt(d)
                        "D = ${fmt(d)}\nx₁ = ${fmt((-b + sq) / (2 * a))}, x₂ = ${fmt((-b - sq) / (2 * a))}"
                    }
                }
            }
        }
        return Solution(task, ans)
    }

    fun fmt(v: Double): String {
        if (v.isNaN() || v.isInfinite()) return "не определено"
        val r = Math.round(v)
        if (abs(v - r) < 1e-9 && abs(v) < 1e15) return r.toString()
        return String.format(java.util.Locale.US, "%.6f", v)
            .trimEnd('0').trimEnd('.').replace('.', ',')
    }
}
