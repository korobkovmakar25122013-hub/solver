plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.photosolver"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.photosolver"
        minSdk = 29
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity-ktx:1.9.2")
    // Модель распознавания вшита в приложение, интернет не нужен
    implementation("com.google.mlkit:text-recognition:16.0.1")
    // Русский OCR для задач словами (офлайн), нужен файл rus.traineddata в assets
    implementation("cz.adaptech.tesseract4android:tesseract4android:4.7.0")
}
