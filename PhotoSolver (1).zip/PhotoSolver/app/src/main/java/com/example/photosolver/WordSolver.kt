package com.example.photosolver

/**
 * Решает типовые школьные текстовые задачи по шаблонам (без интернета и нейросети).
 * Понимает: движение (скорость, время, путь), проценты, «в N раз», «на N больше/меньше»,
 * «на сколько», «по N», деление поровну, «осталось», «всего», среднее, периметр и площадь.
 */
object WordSolver {
    private val numRe = Regex("""\d+(?:[.,]\d+)?""")
    private val moreWords = listOf("больше", "дольше", "быстрее", "дороже", "длиннее", "старше")

    private fun d(s: String) = s.replace(',', '.').toDouble()
    private fun f(v: Double) = Solver.fmt(v)
    private fun has(t: String, vararg w: String) = w.any { t.contains(it) }
    private fun out(step: String, res: String) = "$step\nОтвет: $res"

    private fun numsOutside(t: String, r: IntRange): List<Double> =
        numRe.findAll(t)
            .filter { it.range.first > r.last || it.range.last < r.first }
            .map { d(it.value) }
            .toList()

    fun solve(raw: String): String? {
        val t = raw.lowercase().replace('ё', 'е').replace(Regex("\\s+"), " ")
        val all = numRe.findAll(t).map { d(it.value) }.toList()
        if (all.isEmpty()) return null
        val q = Regex("[^.?!]*(?:сколько|найд|какое|какая|какой|каков|чему|определ|вычисл)[^.?!]*")
            .findAll(t).lastOrNull()?.value ?: t

        // 1. Движение: S = v · t
        val speedRe = Regex("""(\d+(?:[.,]\d+)?)\s*(?:км/ч|км в час|километров в час|м/с|м в секунду)""")
        val speed = speedRe.find(t)?.let { d(it.groupValues[1]) }
        val rest = speedRe.replace(t, " ")
        val timeM = Regex("""(\d+(?:[.,]\d+)?)\s*(ч(?![а-я])|час[а-я]*|мин[а-я]*)""").find(rest)
        val distM = Regex("""(\d+(?:[.,]\d+)?)\s*(км(?![а-я/])|километр[а-я]*)""").find(rest)
        val inMin = timeM?.groupValues?.get(2)?.startsWith("мин") == true
        val time = timeM?.let { d(it.groupValues[1]) / (if (inMin) 60.0 else 1.0) }
        val dist = distM?.let { d(it.groupValues[1]) }
        if (has(q, "скорост") && dist != null && time != null && time > 0) {
            return out("v = S : t = ${f(dist)} : ${f(time)}", f(dist / time))
        }
        if (has(q, "расстоян", "сколько километров", "сколько км", "какой путь") && speed != null && time != null) {
            return out("S = v · t = ${f(speed)} · ${f(time)}", f(speed * time))
        }
        if (has(q, "сколько времени", "сколько часов", "за какое время", "сколько минут") &&
            speed != null && speed > 0 && dist != null
        ) {
            val h = dist / speed
            return if (has(q, "минут")) {
                out("t = S : v = ${f(dist)} : ${f(speed)} (ч), затем · 60", f(h * 60))
            } else {
                out("t = S : v = ${f(dist)} : ${f(speed)}", f(h))
            }
        }

        // 2. Проценты
        val pm = Regex("""(\d+(?:[.,]\d+)?)\s*%""").find(t)
        if (pm != null) {
            val p = d(pm.groupValues[1])
            val others = numsOutside(t, pm.range)
            if (others.isNotEmpty() && p != 0.0) {
                val a = others.first()
                return if (has(t, "найди число", "найдите число", "найти число", "всё число", "все число", "целое")) {
                    out("${f(a)} · 100 : ${f(p)}", f(a * 100 / p))
                } else {
                    out("${f(a)} · ${f(p)} : 100", f(a * p / 100))
                }
            }
        }
        if (has(q, "сколько процентов") && all.size == 2) {
            val x = minOf(all[0], all[1])
            val y = maxOf(all[0], all[1])
            if (y != 0.0) return out("${f(x)} : ${f(y)} · 100", f(x / y * 100) + "%")
        }

        // 3. Геометрия
        val square = Regex("квадрат(?![а-я])").containsMatchIn(t)
        if (has(t, "прямоугольник") && all.size >= 2) {
            if (has(t, "периметр")) return out("P = 2 · (${f(all[0])} + ${f(all[1])})", f(2 * (all[0] + all[1])))
            if (has(t, "площад")) return out("S = ${f(all[0])} · ${f(all[1])}", f(all[0] * all[1]))
        }
        if (square && all.isNotEmpty()) {
            if (has(t, "периметр")) return out("P = 4 · ${f(all[0])}", f(4 * all[0]))
            if (has(t, "площад")) return out("S = ${f(all[0])} · ${f(all[0])}", f(all[0] * all[0]))
        }

        // 4. Среднее
        if (has(t, "средн") && all.size >= 2) {
            return out("(${all.joinToString(" + ") { f(it) }}) : ${all.size}", f(all.sum() / all.size))
        }

        // 5. «На сколько больше/меньше»
        if (has(q, "на сколько") && all.size == 2) {
            val big = maxOf(all[0], all[1])
            val small = minOf(all[0], all[1])
            return out("${f(big)} − ${f(small)}", f(big - small))
        }

        // 6. «В N раз больше/меньше»
        val rm = Regex("""в (\d+(?:[.,]\d+)?) раз[а]? (больше|меньше|дольше|быстрее|дороже|дешевле|длиннее|короче)""").find(t)
        if (rm != null) {
            val n = d(rm.groupValues[1])
            val base = numsOutside(t, rm.range).firstOrNull()
            if (base != null && n != 0.0) {
                val bigger = rm.groupValues[2] in moreWords
                val res = if (bigger) base * n else base / n
                val step = if (bigger) "${f(base)} · ${f(n)}" else "${f(base)} : ${f(n)}"
                return if (has(q, "всего", "вместе", "в сумме")) {
                    out("$step = ${f(res)}; ${f(base)} + ${f(res)}", f(base + res))
                } else {
                    out(step, f(res))
                }
            }
        }

        // 7. «На N больше/меньше»
        val dm = Regex("""на (\d+(?:[.,]\d+)?) (больше|меньше|дольше|короче|длиннее|дороже|дешевле|старше|моложе|быстрее|медленнее)""").find(t)
        if (dm != null) {
            val n = d(dm.groupValues[1])
            val base = numsOutside(t, dm.range).firstOrNull()
            if (base != null) {
                val plus = dm.groupValues[2] in moreWords
                val res = if (plus) base + n else base - n
                val step = if (plus) "${f(base)} + ${f(n)}" else "${f(base)} − ${f(n)}"
                return if (has(q, "всего", "вместе", "в сумме", "обе", "обоих")) {
                    out("$step = ${f(res)}; ${f(base)} + ${f(res)}", f(base + res))
                } else {
                    out(step, f(res))
                }
            }
        }

        // 8. «По N» (равные группы)
        if (Regex("""по \d""").containsMatchIn(t) && has(q, "всего", "сколько") && all.size == 2 && !has(t, "поровну")) {
            return out("${f(all[0])} · ${f(all[1])}", f(all[0] * all[1]))
        }

        // 9. Деление поровну
        if (has(t, "поровну", "разделили", "разделить", "разложили", "раздали") && all.size == 2) {
            val big = maxOf(all[0], all[1])
            val small = minOf(all[0], all[1])
            if (small != 0.0) return out("${f(big)} : ${f(small)}", f(big / small))
        }

        // 10. Осталось
        if (has(t, "остал", "убрали", "потратил", "отдал", "съел", "продали", "ушло") && all.size >= 2) {
            val res = all[0] - all.drop(1).sum()
            val step = all.joinToString(" − ") { f(it) }
            return out(step, f(res))
        }

        // 11. Всего
        if (has(t, "всего", "вместе", "в сумме", "общее", "обоих", "сумма") && all.size >= 2) {
            return out(all.joinToString(" + ") { f(it) }, f(all.sum()))
        }

        return null
    }
}
